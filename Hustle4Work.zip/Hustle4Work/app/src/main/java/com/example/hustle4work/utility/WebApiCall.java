package com.example.hustle4work.utility;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.example.hustle4work.Interface.ApiInterface;
import com.example.hustle4work.model.SignUpResponse;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.HashMap;
import java.util.Map;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class WebApiCall {

    ApiInterface webApiInterface;
    Context context;
    //CustomProgressDialog customProgressDialog;
    Gson gson;
    private String baseUrl;
    private String from;




    public WebApiCall(Context context) {
        this.context = context;
       // customProgressDialog = new CustomProgressDialog(context);
        this.from = from;

        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient defaultHttpClient = new OkHttpClient.Builder().addInterceptor(interceptor).build();

        baseUrl = Baseurl.BASE_URL;
        gson = new GsonBuilder().setLenient().create();
        Retrofit retrofit = new Retrofit.Builder().baseUrl(baseUrl).addConverterFactory(GsonConverterFactory.create(gson))
                .client(defaultHttpClient).build();
        webApiInterface = retrofit.create(ApiInterface.class);

    }



    public void registerUser(String username, String email, String password, String phoneNumber, String address) {



       // UserService userService = retrofit.create(UserService.class);

        Map<String, String> params = new HashMap<>();
        params.put("email", email);
        params.put("password", password);
        params.put("username", username);
        params.put("address", address);
        params.put("phonenumber", phoneNumber);

        Log.i("baseUrl",""+baseUrl);


        Call<SignUpResponse> signup_Service = webApiInterface.signUp(params);

        signup_Service.enqueue(new Callback<SignUpResponse>() {
            @Override
            public void onResponse(Call<SignUpResponse> call, Response<SignUpResponse> response) {

                showToast("ok..");
            }

            @Override
            public void onFailure(Call<SignUpResponse> call, Throwable t) {
                showToast("not ok..");
            }

        });
    }

    private void showToast(String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }
}
