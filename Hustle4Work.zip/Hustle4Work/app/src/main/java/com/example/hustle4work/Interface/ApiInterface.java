package com.example.hustle4work.Interface;

import com.example.hustle4work.model.SignUpResponse;

import java.util.Map;

import retrofit2.Call;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiInterface {

    @FormUrlEncoded
    @POST("signup")
    Call<SignUpResponse> signUp(@FieldMap Map<String, String> params);

}
