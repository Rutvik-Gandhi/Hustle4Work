package com.example.hustle4work.utility;

public class Baseurl {

    public static final String BASE_URL = "http://localhost:5000/users/";
}
