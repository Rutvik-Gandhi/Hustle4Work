package com.example.hustle4work.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import android.widget.TextView;
import android.widget.Toast;

import com.example.hustle4work.R;

public class LoginActivity extends AppCompatActivity {


    EditText editTextUsername ,editTxtPassword;
    TextView txtSignUp;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        editTextUsername = findViewById(R.id.editTextUsername);
        editTxtPassword = findViewById(R.id.editTxtPassword);
        txtSignUp = findViewById(R.id.txtSignUp);

        validateFields();

        txtSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(LoginActivity.this, SignUpActivity.class);
                startActivity(i);
            }
        });
    }

    private void validateFields() {
        String username = editTextUsername.getText().toString();
        String password = editTxtPassword.getText().toString();

        if (username.isEmpty()) {
            showToast("Username is required");
        }

        else if (password.isEmpty()) {
            showToast("Password is required");
        }
    }

    private void showToast(String message) {
        Toast.makeText(LoginActivity.this, message, Toast.LENGTH_SHORT).show();
    }
}